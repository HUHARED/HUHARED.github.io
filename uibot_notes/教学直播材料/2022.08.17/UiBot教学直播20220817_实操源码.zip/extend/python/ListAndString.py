from typing import Union


# 列表相关
# 根据索引删除元素，并返回删除后的列表
def pop_element(list_obj: list, index_info: int):
    # 入参：列表、索引
    # 出参：如果索引在数组索引范围内返回删除元素后的列表，反之返回False
    len_info = len(list_obj)
    print(len_info)
    if (0 <= index_info < len_info):
        list_obj.pop(index_info)
        res = list_obj
    else:
        res = False
    return res


# 去重列表重复项，并返回去重后的列表
def delete_all_duplicate(list_obj: list):
    # 入参：列表
    # 出参：返回去重后的列表
    # 说明：保留列表中遇见的第一个元素
    tmp = {k: "" for k in list_obj}
    res = [i for i in tmp.keys()]
    return res


# 去重列表中的特定元素
def delete_duplicate(list_obj: list, element: object):
    # 入参：列表、要去重的元素
    # 出参：如果要去重的元素在列表中则进行去重并返回去重后的列表，反之返回元列表
    # 说明：保留列表中遇见的第一个元素
    if element in list_obj:
        # 方法1：通用方法
        # res = []
        # for i in list_obj:
        #     if i != element:
        #         res.append(i)
        #     else:
        #         if i not in res:
        #             res.append(i)
        # 方法2：先获取特定元素不存在的列表，以及特定元素的索引，然后再插入特点元素即可
        res = [i for i in list_obj if i != element]
        tmp = [i for i in range(0, len(list_obj)) if list_obj[i] == element]
        res.insert(tmp[0], list_obj[tmp[0]])
        return res
    else:
        res = list_obj
    return res


# 数组和字符串通用
# 根据元素获取元素在列表中的索引
def get_index(iter_obj: Union[str, int], element: object, flag: object = False):
    # 入参：列表/字符串、元素、是否只返回第一个元素的索引，默认为True
    # 出参：如果元素在列表/字符串内则返回索引(如果列表内只有一个元素则返回索引，如果存在多个元素则返回元素索引的列表)，反之返回False
    if element in iter_obj:
        res = [i for i in range(0, len(iter_obj)) if iter_obj[i] == element]
    else:
        res = False
    return res[0] if (flag and res) else res


# 获取列表或字符串中元素出现的次数
def get_count(iter_obj: Union[str, int], element: object):
    # 入参：列表/字符串、要计数的元素
    # 出参：该元素出现在列表/字符串中的次数
    return iter_obj.count(element)


# 字符串或者列表反转
def reverse_list(iter_obj: Union[str, int]):
    # 入参：列表/字符串
    # 出参：反转后的列表/字符串
    return iter_obj[::-1]


# 扩展
# 执行eval语句并返回eval结果
def my_eval(command_str: str):
    # 入参：字符串
    # 出参：字符串在eval执行的结果
    res = eval(command_str)
    return res


if __name__ == '__main__':
    a=pop_element(["a","b","c"], )
    print(a)